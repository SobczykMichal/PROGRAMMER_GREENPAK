
//namespace foo
//{
//  #include "Arduino.h"
//  #include "CRC.h"
//
//  int foo(int n);
//}


#include "Arduino.h"
#include "CRC.h"

int foo(int n);
